console.log('Ejercicios SCORM cargados');

document.addEventListener('DOMContentLoaded', () => {
  const links = document.querySelectorAll('a');
  links.forEach(link => {
    link.addEventListener('click', (event) => {
      const target = link.getAttribute('href');
      if (target && target.endsWith('.html')) {
        event.preventDefault();
        window.location.href = target;
      }
    });
  });
});
